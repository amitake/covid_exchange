# coviddollar

A package for comparison dollar exchange rate fluctuations and changes in the number of new covid-19 infections

# Example of use
```
$pip coviddollar
$python coviddollar.py 30
```

usage: coviddollar.py days
days: How many days of data to use

